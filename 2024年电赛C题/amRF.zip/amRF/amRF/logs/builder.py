# 2024-08-01T03:20:12.155462
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/22479/Desktop/amRF/amRF")

platform = client.create_platform_component(name = "M_DDS",hw = "C:/Users/22479/Desktop/amRF/amRF/M_DAC_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0")

comp = client.create_app_component(name="M_DAC_APP",platform = "C:/Users/22479/Desktop/amRF/amRF/M_DDS/export/M_DDS/M_DDS.xpfm",domain = "standalone_ps7_cortexa9_0")

client.delete_platform_component(name="M_DDS")

client.delete_component(name="xsdps_raw_example")

client.delete_component(name="M_DAC_APP")

platform = client.create_platform_component(name = "platform",hw = "C:/Users/22479/Desktop/amRF/amRF/M_DAC_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0")

comp = client.create_app_component(name="hello_world",platform = "C:/Users/22479/Desktop/amRF/amRF/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

platform = client.get_platform_component(name="platform")
status = platform.build()

comp = client.get_component(name="hello_world")
comp.build()

vitis.dispose()

