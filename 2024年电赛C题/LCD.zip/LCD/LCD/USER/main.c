#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "24cxx.h"
#include "w25qxx.h"
#include "touch.h"
#include "math.h"
#include "ad9959.h"

//�����Ļ�������Ͻ���ʾ"RST"
// void Load_Drow_Dialog(void)
// {
// 	LCD_Clear(WHITE);	//����   
//  	POINT_COLOR=BLUE;	//��������Ϊ��ɫ 
// 	LCD_ShowString(lcddev.width-40,0,200,24,24,"RST");//��ʾ��������
//   	POINT_COLOR=BLUE;	//���û�����ɫ 
// }


////////////////////////////////////////////////////////////////////////////////
//���ݴ�����ר�в���
//��ˮƽ��
//x0,y0:����
//len:�߳���
//color:��ɫ

//������֮��ľ���ֵ 
//x1,x2����ȡ��ֵ��������
//����ֵ��|x1-x2|
u16 my_abs(u16 x1,u16 x2)
{			 
	if(x1>x2)return x1-x2;
	else return x2-x1;
}  
//��һ������
//(x1,y1),(x2,y2):��������ʼ����
//size�������Ĵ�ϸ�̶�
//color����������ɫ

////////////////////////////////////////////////////////////////////////////////
 //5�����ص����ɫ												 
const u16 POINT_COLOR_TBL[CT_MAX_TOUCH]={RED,GREEN,BLUE,BROWN,GRED};

const int area1_xl = 50;
const int area1_xr = 230;
const int area1_y[11] = {40, 100, 160, 220, 280, 340, 400, 460, 520, 580, 640};

//��ʼ����
void Wave_Init(void);

//��Ƶ��
void Frequency(void);
void Select_Frequency(void);

//�ķ�ֵ
void Amplitude_modulation(void);
void Select_Amplitude_modulation(void);

//�ĵ���ֵ
void Delta(void);
// void Select_Delta(void);

//��λ
void Phase(void);

//ʱ��
void Delay(void);

//ѡ�ź�
void Amis(void);

//���
void AmLoss(void);
void Select_AmLoss(void);

void ctp_test(void);
void Select(void);
void Send_Data(void);
// void Send_Data_Volt(uint8_t V);

uint8_t para;
uint8_t para1;
uint8_t flag;

const int dpi = 128;

double Vo;
double Vm = 1.0;
double Vd;

uint32_t f;

//��һ���㣬ÿ���ҽ��뺯�����費��Ҫ�ѵ�����
int main(void)
{	 		    
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(9600);	 	//���ڳ�ʼ��Ϊ115200
	
	LCD_Init();
	Init_AD9959();
	tp_dev.init();

	POINT_COLOR=BLUE;//��������Ϊ��ɫ

  AD9959_Set_Freq(30000000);
	set_value(1,1);
	//AD9959_SetAmp4Channel(512,512,100,100);
	AD9959_SetPhase4Channel(0,0,0,0);

	// delay_ms(1500);
	// Load_Drow_Dialog();	 	
	if(tp_dev.touchtype&0X80) ctp_test();	//����������
	
}


void ctp_test(void)
{
	Wave_Init();

	while (1)
	{
		tp_dev.scan(0);
		// for (t = 0; 0 < CT_MAX_TOUCH; 0++)
		// {
		if (flag)
		{
			Wave_Init();
			flag = 0;
		}
		
		while (!((tp_dev.sta) & (1 << 0)))
		{
			tp_dev.scan(0);
		}

		if ((tp_dev.sta) & (1 << 0))
		{
			if(tp_dev.x[0] > 290 && tp_dev.y[0] > 680 && tp_dev.x[0] < 470 && tp_dev.y[0] < 750)
			{
				para = 0x20;
				para1 = 0x00;
				Send_Data();
			}
			
			if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
			{
				if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
				{
					Frequency();
					Select_Frequency();
				}
				else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
				{
					Amplitude_modulation();
					Select_Amplitude_modulation();
				}
				else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
				{
					Delta();
					para = 0x04;
					Select();
				}
				else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
				{
					Phase();
					para = 0x08;
					Select();
				}
				else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
				{
					Delay();
					para = 0x10;
					Select();
				}
				else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
				{
					Amis();
					para = 0x01;
					Select();
				}
				else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
				{
					AmLoss();
					para = 0x02;
					Select_AmLoss();
				}
			}
		}
		
		while ((tp_dev.sta) & (1 << 0))
		{
			tp_dev.scan(0);
		}
		
		// }
		delay_ms(5);
	}
}

void Wave_Init()
{
	LCD_Clear(WHITE);	// ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "Amis");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "Frequency");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "Amplitude_Modu");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "Phase");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "Delta");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "AmLoss");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "Delay");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(300, 700, 150, 24, 24, "Start");
	LCD_DrawRectangle(290, 680, 470, 750);
}

void Frequency(void)
{
	LCD_Clear(WHITE);  // ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "30M");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "31M");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "32M");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "33M");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "34M");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "35M");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "36M");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(60, 460, 200, 24, 24, "37M");
	LCD_DrawRectangle(50, 450, 280, 500);

	LCD_ShowString(60, 520, 200, 24, 24, "38M");
	LCD_DrawRectangle(50, 510, 280, 560);

	LCD_ShowString(60, 580, 200, 24, 24, "39M");
	LCD_DrawRectangle(50, 570, 280, 620);

	LCD_ShowString(60, 640, 200, 24, 24, "40M");
	LCD_DrawRectangle(50, 630, 280, 680);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Select_Frequency(void)
{
	while ((tp_dev.sta) & (1 << 0))
	{
		tp_dev.scan(0);
	};

	while (1)
	{
		// tp_dev.x[0] = 0xffff;
		// tp_dev.y[0] = 0xffff;
		delay_ms(5);

		while (!((tp_dev.sta) & (1 << 0)))
		{
			tp_dev.scan(0);
		}

		// for (0 = 0; 0 < CT_MAX_TOUCH; 0++)
		// {
		if ((tp_dev.sta) & (1 << 0))
		{
			if (tp_dev.x[0] > 300 && tp_dev.x[0] < 470)
			{
				if (tp_dev.y[0] > 65 && tp_dev.y[0] < 100)
				{
					flag = 1;
					// tp_dev.x[0] = 0xffff;
					// tp_dev.y[0] = 0xffff;
					para = 0x00;

					return;
				}
			}
			if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
			{
				if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
				{
					f = 30000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
				{
					f = 31000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
				{
					f = 32000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
				{
					f = 33000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
				{
					f = 34000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
				{
					f = 35000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
				{
					f = 36000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[7] && tp_dev.y[0] < area1_y[7] + 60)
				{
					f = 37000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[8] && tp_dev.y[0] < area1_y[8] + 60)
				{
					f = 38000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[9] && tp_dev.y[0] < area1_y[9] + 60)
				{
					f = 39000000;
					AD9959_Set_Freq(f);
				}
				else if (tp_dev.y[0] > area1_y[10] && tp_dev.y[0] < area1_y[10] + 60)
				{
					f = 40000000;
					AD9959_Set_Freq(f);
				}

				POINT_COLOR = RED; // ��������Ϊ��ɫ
				LCD_ShowString(100, 750, 200, 24, 24, "Updated");
				delay_ms(20);
				POINT_COLOR = BLUE; // ��������Ϊ��ɫ
				LCD_Fill(100, 750, 300, 774, WHITE);
			}
		}

		while ((tp_dev.sta) & (1 << 0))
		{
			tp_dev.scan(0);
		};
	}
	//}
}

void Amplitude_modulation(void)
{
	LCD_Clear(WHITE);  // ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "100mV");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "200mV");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "300mV");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "400mV");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "500mV");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "600mV");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "700mV");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(60, 460, 200, 24, 24, "800mV");
	LCD_DrawRectangle(50, 450, 280, 500);

	LCD_ShowString(60, 520, 200, 24, 24, "900mV");
	LCD_DrawRectangle(50, 510, 280, 560);

	LCD_ShowString(60, 580, 200, 24, 24, "1V");
	LCD_DrawRectangle(50, 570, 280, 620);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Select_Amplitude_modulation(void)
{
	while ((tp_dev.sta) & (1 << 0))
	{
		tp_dev.scan(0);
	};

	while (1)
	{
		// tp_dev.x[0] = 0xffff;
		// tp_dev.y[0] = 0xffff;
		delay_ms(5);

		while (!((tp_dev.sta) & (1 << 0)))
		{
			tp_dev.scan(0);
		}

		// for (0 = 0; 0 < CT_MAX_TOUCH; 0++)
		// {
		if ((tp_dev.sta) & (1 << 0))
		{
			if (tp_dev.x[0] > 300 && tp_dev.x[0] < 470)
			{
				if (tp_dev.y[0] > 65 && tp_dev.y[0] < 100)
				{
					flag = 1;
					// tp_dev.x[0] = 0xffff;
					// tp_dev.y[0] = 0xffff;
					para = 0x00;

					return;
				}
			}
			if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
			{
				if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
				{
					Vm = 0.1;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
				{
					Vm = 0.2;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
				{
					Vm = 0.3;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
				{
					Vm = 0.4;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
				{
					Vm = 0.5;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
				{
					Vm = 0.6;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
				{
					Vm = 0.7;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[7] && tp_dev.y[0] < area1_y[7] + 60)
				{
					Vm = 0.8;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[8] && tp_dev.y[0] < area1_y[8] + 60)
				{
					Vm = 0.9;
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[9] && tp_dev.y[0] < area1_y[9] + 60)
				{
					Vm = 1.0;
					set_value(Vm, Vm);
				}

				POINT_COLOR = RED; // ��������Ϊ��ɫ
				LCD_ShowString(100, 750, 200, 24, 24, "Updated");
				delay_ms(20);
				POINT_COLOR = BLUE; // ��������Ϊ��ɫ
				LCD_Fill(100, 750, 300, 774, WHITE);
			}
			
		}

		while ((tp_dev.sta) & (1 << 0))
		{
			tp_dev.scan(0);
		};
	}
	//}
}

void Delta(void)
{
	LCD_Clear(WHITE);	// ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "30%");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "40%");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "50%");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "60%");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "70%");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "80%");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "90%");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Select_Delta(void)
{
	// while ((tp_dev.sta) & (1 << 0))
	// {
	// 	tp_dev.scan(0);
	// };

	// while (1)
	// {
	// 	// tp_dev.x[0] = 0xffff;
	// 	// tp_dev.y[0] = 0xffff;
	// 	delay_ms(5);

	// 	while (!((tp_dev.sta) & (1 << 0)))
	// 	{
	// 		tp_dev.scan(0);
	// 	}

	// 	// for (0 = 0; 0 < CT_MAX_TOUCH; 0++)
	// 	// {
	// 	if ((tp_dev.sta) & (1 << 0))
	// 	{
	// 		if (tp_dev.x[0] > 300 && tp_dev.x[0] < 470)
	// 		{
	// 			if (tp_dev.y[0] > 65 && tp_dev.y[0] < 100)
	// 			{
	// 				flag = 1;
	// 				// tp_dev.x[0] = 0xffff;
	// 				// tp_dev.y[0] = 0xffff;
	// 				para = 0x00;

	// 				return;
	// 			}
	// 		}

	// 		if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
	// 		{
	// 			if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.3 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.4 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.5 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.6 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.7 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.8 / dpi);
	// 			}
	// 			else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
	// 			{
	// 				Vd = ((float)Vo * 0.9 / dpi);
	// 			}

	// 			Send_Data_Volt(Vd);
	// 		}
	// 	}

	// 	while ((tp_dev.sta) & (1 << 0))
	// 	{
	// 		tp_dev.scan(0);
	// 	};
	// }
	// //}
}

void Phase(void)
{
	LCD_Clear(WHITE);	// ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "0");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "30");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "60");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "90");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "120");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "150");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "180");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Delay(void)
{
	LCD_Clear(WHITE);	// ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "50ns");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "80ns");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "110ns");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "140ns");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "170ns");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "200ns");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Amis(void)
{
	LCD_Clear(WHITE);	// ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "CW");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "AM");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void AmLoss(void)
{
	LCD_Clear(WHITE);  // ????
	POINT_COLOR = BLUE; // ????????????

	LCD_ShowString(60, 40, 200, 24, 24, "0dB");
	LCD_DrawRectangle(50, 30, 280, 80);

	LCD_ShowString(60, 100, 200, 24, 24, "-2dB");
	LCD_DrawRectangle(50, 90, 280, 140);

	LCD_ShowString(60, 160, 200, 24, 24, "-4dB");
	LCD_DrawRectangle(50, 150, 280, 200);

	LCD_ShowString(60, 220, 200, 24, 24, "-6dB");
	LCD_DrawRectangle(50, 210, 280, 260);

	LCD_ShowString(60, 280, 200, 24, 24, "-8dB");
	LCD_DrawRectangle(50, 270, 280, 320);

	LCD_ShowString(60, 340, 200, 24, 24, "-10dB");
	LCD_DrawRectangle(50, 330, 280, 380);

	LCD_ShowString(60, 400, 200, 24, 24, "-12dB");
	LCD_DrawRectangle(50, 390, 280, 440);

	LCD_ShowString(60, 460, 200, 24, 24, "-14dB");
	LCD_DrawRectangle(50, 450, 280, 500);

	LCD_ShowString(60, 520, 200, 24, 24, "-16dB");
	LCD_DrawRectangle(50, 510, 280, 560);

	LCD_ShowString(60, 580, 200, 24, 24, "-18dB");
	LCD_DrawRectangle(50, 570, 280, 620);

	LCD_ShowString(60, 640, 200, 24, 24, "-20dB");
	LCD_DrawRectangle(50, 630, 280, 680);

	LCD_ShowString(300, 70, 100, 24, 24, "BACK");
	LCD_DrawRectangle(290, 65, 470, 100);
}

void Select_AmLoss(void)
{
	while ((tp_dev.sta) & (1 << 0))
	{
		tp_dev.scan(0);
	};

	while (1)
	{
		// tp_dev.x[0] = 0xffff;
		// tp_dev.y[0] = 0xffff;
		delay_ms(5);

		while (!((tp_dev.sta) & (1 << 0)))
		{
			tp_dev.scan(0);
		}

		// for (0 = 0; 0 < CT_MAX_TOUCH; 0++)
		// {
		if ((tp_dev.sta) & (1 << 0))
		{
			if (tp_dev.x[0] > 300 && tp_dev.x[0] < 470)
			{
				if (tp_dev.y[0] > 65 && tp_dev.y[0] < 100)
				{
					flag = 1;
					// tp_dev.x[0] = 0xffff;
					// tp_dev.y[0] = 0xffff;
					para = 0x00;

					return;
				}
			}

			if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
			{
				if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
				{
					set_value(Vm, Vm);
				}
				else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
				{
					set_value(Vm, Vm * 0.631);//2
				}
				else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
				{
					set_value(Vm, Vm * 0.398);//4
				}
				else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
				{
					set_value(Vm, Vm * 0.251);//6
				}
				else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
				{
					set_value(Vm, Vm * 0.1584);//8
				}
				else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
				{
					set_value(Vm, Vm * 0.1);//10
				}
				else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
				{
					set_value(Vm, Vm * 0.063);
				}
				else if (tp_dev.y[0] > area1_y[7] && tp_dev.y[0] < area1_y[7] + 60)
				{
					set_value(Vm, Vm * 0.0398);
				}
				else if (tp_dev.y[0] > area1_y[8] && tp_dev.y[0] < area1_y[8] + 60)
				{
					set_value(Vm, Vm * 0.0251);
				}
				else if (tp_dev.y[0] > area1_y[9] && tp_dev.y[0] < area1_y[9] + 60)
				{
					set_value(Vm, Vm * 0.01585);
				}
				else if (tp_dev.y[0] > area1_y[10] && tp_dev.y[0] < area1_y[10] + 60)
				{
					set_value(Vm, Vm * 0.01);
				}

				// Send_Data_Volt(Vm);
			}
		}

		while ((tp_dev.sta) & (1 << 0))
		{
			tp_dev.scan(0);
		};
	}
	//}
}

void Select(void)
{
	while ((tp_dev.sta) & (1 << 0))
	{
		tp_dev.scan(0);
	};

	while (1)
	{
		// tp_dev.x[0] = 0xffff;
		// tp_dev.y[0] = 0xffff;
		delay_ms(5);

		while (!((tp_dev.sta) & (1 << 0)))
		{
			tp_dev.scan(0);
		}
		
		// for (0 = 0; 0 < CT_MAX_TOUCH; 0++)
		// {
			if ((tp_dev.sta) & (1 << 0))
			{
				if (tp_dev.x[0] > 300 && tp_dev.x[0] < 470)
				{
					if (tp_dev.y[0] > 65 && tp_dev.y[0] < 100)
					{
						flag = 1;
						// tp_dev.x[0] = 0xffff;
						// tp_dev.y[0] = 0xffff;
						para = 0x00;

						return;
					}
				}

				if (tp_dev.x[0] > area1_xl && tp_dev.x[0] < area1_xr)
				{
					if (tp_dev.y[0] > area1_y[0] && tp_dev.y[0] < area1_y[0] + 60)
					{
						para1 = 0x00;			
					}
					else if (tp_dev.y[0] > area1_y[1] && tp_dev.y[0] < area1_y[1] + 60)
					{
						para1 = 0x01;
					}
					else if (tp_dev.y[0] > area1_y[2] && tp_dev.y[0] < area1_y[2] + 60)
					{
						para1 = 0x02;
					}
					else if (tp_dev.y[0] > area1_y[3] && tp_dev.y[0] < area1_y[3] + 60)
					{
						para1 = 0x03;
					}
					else if (tp_dev.y[0] > area1_y[4] && tp_dev.y[0] < area1_y[4] + 60)
					{
						para1 = 0x04;
					}
					else if (tp_dev.y[0] > area1_y[5] && tp_dev.y[0] < area1_y[5] + 60)
					{
						para1 = 0x05;
					}
					else if (tp_dev.y[0] > area1_y[6] && tp_dev.y[0] < area1_y[6] + 60)
					{
						para1 = 0x07;
					}

					Send_Data();
				}
			}

			while ((tp_dev.sta) & (1 << 0))
			{
				tp_dev.scan(0);
			};
	}
	//}
}

void Send_Data(void)
{
		USART_ClearFlag(USART1, USART_FLAG_TC);
		USART_SendData(USART1, para); // �򴮿�1��������
		while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET); // �ȴ����ͽ���

		USART_SendData(USART1, para1); // �򴮿�1��������
		while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET); // �ȴ����ͽ���
		para1 = 0;

		POINT_COLOR = RED; // ��������Ϊ��ɫ
		LCD_ShowString(100, 750, 200, 24, 24, "Updated");
		delay_ms(20);
		POINT_COLOR = BLUE; // ��������Ϊ��ɫ
		LCD_Fill(100, 750, 300, 774, WHITE);

		return;
}

// void Send_Data_Volt(uint8_t V)
// {
// 	USART_ClearFlag(USART1, USART_FLAG_TC);
// 	USART_SendData(USART1, para); // �򴮿�1��������
// 	while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET)
// 		; // �ȴ����ͽ���

// 	USART_SendData(USART1, V); // �򴮿�1��������
// 	while (USART_GetFlagStatus(USART1, USART_FLAG_TC) != SET)
// 		; // �ȴ����ͽ���
// 	para1 = 0;

// 	POINT_COLOR = BLUE; // ��������Ϊ��ɫ
// 	LCD_ShowString(300, 150, 100, 24, 24, "Updated");
// 	delay_ms(20);
// 	POINT_COLOR = BLUE; // ��������Ϊ��ɫ
// 	LCD_Fill(300, 150, 400, 174, WHITE);

// 	return;
// }

